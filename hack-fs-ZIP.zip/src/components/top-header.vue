<template>
	<div class="top-header">
		<el-menu :default-active="activeIndex" class="my-el-menu" mode="horizontal" @select="handleSelect">
			<el-submenu index="1">
				<template slot="title"><span class="el-icon-menu"></span></template>
				<el-menu-item index="1-1"><span class="el-icon-search"></span>Retrieval</el-menu-item>
				<el-menu-item index="1-2"><span class="el-icon-upload2"></span>Upload</el-menu-item>
				<!-- <el-menu-item index="1-3"><span class="el-icon-s-order"></span>下载记录</el-menu-item> -->
			</el-submenu>
			<!-- 未登录 -->
			<el-menu-item v-if="!(this.$store.state.authToken)" index="2"><span class="el-icon-user-solid"></span></el-menu-item>
			<!-- 已登录 -->
			<el-submenu v-if="this.$store.state.authToken" index="3">
				<template slot="title"><span class="el-icon-user-solid"></span><span>{{$store.state.currentUser.username}}</span></template>
				<el-menu-item index="3-1"><span class="el-icon-s-finance"></span>Wallet</el-menu-item>
				<el-menu-item index="3-2"><span class="el-icon-s-order"></span>Download records</el-menu-item>
				<el-menu-item index="3-3"><span class="el-icon-upload2"></span>Upload records</el-menu-item>
				<!-- <el-menu-item index="3-4"><span class="el-icon-refresh-right"></span>Browsing history</el-menu-item> -->
				<el-menu-item index="3-5"><span class="el-icon-s-tools"></span>Security setting</el-menu-item>
				<el-menu-item index="3-6"><span class="el-icon-circle-close"></span>Logout</el-menu-item>
			</el-submenu>
		</el-menu>
		<div class="line"></div>
	</div>
</template>

<script>
	export default {
		data(){
			return {
				//默认进入 展示检索文件
				activeIndex: '1-1',
			}
		},
		methods: {
			handleSelect(key, keyPath) {
				// console.log(key, keyPath)
				switch (key){
					case '1-1':
						if(this.$route.name != 'index'){
							this.$router.replace({'path': '/'})
						}
						break;
					case '1-2':
						if(this.$store.state.authToken){
							if(this.$route.name != 'upload'){
								this.$router.replace({'path': '/upload'})
							}
						}else{
							this.$message.error('Please log in')
						}
						break;
					case '1-3':
						if(this.$route.name != 'downloadList'){
							this.$router.replace({'path': '/downloadList'})
						}
						break;
					case '2':
						//已登录
						if(this.$store.state.authToken){
							//
						}else{
							//未登录
							if(this.$route.name != 'login'){
								this.$router.replace({'path': '/login'})
							}
						}
						break;
					case '3-1':
						if(this.$route.name != 'wallet'){
							this.$router.replace({'path': '/wallet'})
						}
						break;
					case '3-2':
						if(this.$route.name != 'downloadRec'){
							this.$router.replace({'path': '/downloadRec'})
						}
						break;
					case '3-3':
						if(this.$route.name != 'uploadRec'){
							this.$router.replace({'path': '/uploadRec'})
						}
						break;
					case '3-4':
						if(this.$route.name != 'viewRec'){
							this.$router.replace({'path': '/viewRec'})
						}
						break;
					case '3-5':
						if(this.$route.name != 'setting'){
							this.$router.replace({'path': '/setting'})
						}
						break;
					case '3-6':
					this.$confirm('Are you sure you want to logout?', 'Warning', {
						confirmButtonText: 'OK',
						cancelButtonText: 'Cancel',
						type: 'warning'
					}).then(() => {
						this.$message({
							type: 'success',
							message: 'Logout successful!'
						})
						this.$store.commit('logout')
						if(this.$route.name != 'index'){
							this.$router.replace({'path': '/'})
						}
					}).catch(() => {
						this.$message({
							type: 'info',
							message: 'cancel'
						})
					})
						break;
				}
			}
		},
		mounted() {
			
		}
	}
</script>

<style lang="less">
	.top-header{
		.my-el-menu{
			padding-left: 10%;
			padding-right: 10%;
		}
	}
</style>
