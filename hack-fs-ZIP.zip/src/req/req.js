import axios from 'axios'

// let SERVER_IP = 'http://45.32.19.182:3000'
let SERVER_IP = '/api'

export default {
	//注册
	apiReg(username, password, email, cb){
		axios({
			method: 'post',
				url: SERVER_IP + '/register',
				data: {
					username,
					password,
					email
				}
		})
		.then(res=>{
			if(cb.success){
				cb.success(res)
			}
		})
		.catch(err=>{
			if(cb.fail){
				cb.fail(err)
			}
		})
	},
	//登录
	apiLogin(username, password, cb){
		axios({
			method: 'post',
				url: SERVER_IP + '/login',
				data: {
					username,
					password
				}
		})
		.then(res=>{
			if(cb.success){
				cb.success(res)
			}
		})
		.catch(err=>{
			if(cb.fail){
				cb.fail(err)
			}
		})
	},
	//检索
	// 搜索栏检索时，type=1；icon时type=2
	apiRetrieve(description, type, authToken, cb){
		axios({
			method: 'post',
				url: SERVER_IP + '/retrieve',
				// headers: {
				// 	'authorization': authToken
				// },
				data: {
					description,
					type
				}
		})
		.then(res=>{
			if(cb.success){
				cb.success(res)
			}
		})
		.catch(err=>{
			if(cb.fail){
				cb.fail(err)
			}
		})
	},
	//上传
	apiUpload(fd, authToken, cb){
		axios({
			method: 'post',
				url: SERVER_IP + '/upload',
				headers: {
					'Content-Type': 'multipart/form-data',
					'authorization': authToken
				},
				data: fd
		})
		.then(res=>{
			if(cb.success){
				cb.success(res)
			}
		})
		.catch(err=>{
			if(cb.fail){
				cb.fail(err)
			}
		})
	},
	//创建钱包
	apicreateWallet(walletname, type, token, authToken, cb){
		axios({
			method: 'post',
				url: SERVER_IP + '/createWallet',
				headers: {
					'authorization': authToken
				},
				data: {
					walletname,
					type,
					token
				}
		})
		.then(res=>{
			if(cb.success){
				cb.success(res)
			}
		})
		.catch(err=>{
			if(cb.fail){
				cb.fail(err)
			}
		})
	},
	//支付
	apiPayment(fromAddr, toAddr, amnt, cid, token, authToken, cb){
		axios({
			method: 'post',
				url: SERVER_IP + '/retrieve/download/payment',
				headers: {
					'authorization': authToken
				},
				data: {
					'from': fromAddr,
					'to': toAddr,
					amnt,
					cid,
					token
				}
		})
		.then(res=>{
			if(cb.success){
				cb.success(res)
			}
		})
		.catch(err=>{
			if(cb.fail){
				cb.fail(err)
			}
		})
	},
	//下载
	apiDownload(filename, cid, token, authToken, cb){
		axios({
			method: 'post',
				url: SERVER_IP + '/retrieve/download',
				headers: {
					'authorization': authToken
				},
				responseType: 'blob',
				data: {
					filename,
					cid,
					token
				}
		})
		.then(res=>{
			if(cb.success){
				cb.success(res)
			}
		})
		.catch(err=>{
			if(cb.fail){
				cb.fail(err)
			}
		})
	},
	//改密码
	changePassword(username, newPassword, authToken, cb){
		axios({
			method: 'post',
				url: SERVER_IP + '/changePassword',
				headers: {
					'authorization': authToken
				},
				data: {
					username,
					newPassword
				}
		})
		.then(res=>{
			if(cb.success){
				cb.success(res)
			}
		})
		.catch(err=>{
			if(cb.fail){
				cb.fail(err)
			}
		})
	},
	//上传记录/下载记录 record 1表示查询下载记录；2表示上传记录
	Record(token, record, authToken, cb){
		axios({
			method: 'post',
				url: SERVER_IP + '/Record',
				headers: {
					'authorization': authToken
				},
				data: {
					token,
					record
				}
		})
		.then(res=>{
			if(cb.success){
				cb.success(res)
			}
		})
		.catch(err=>{
			if(cb.fail){
				cb.fail(err)
			}
		})
	},
}