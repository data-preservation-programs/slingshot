<template>
	<div class="fs-setting">
		<h1 class="index-titile">Security Setting</h1>
		
		<el-form v-loading="loading" :model="ruleForm" :rules="rules" ref="ruleForm" label-width="auto" class="my-ruleForm">
			<el-form-item label="User" prop="userName">
				<el-input disabled type="text" v-model="$store.state.currentUser.username" autocomplete="off"></el-input>
			</el-form-item>
			<el-form-item label="Password" prop="password">
				<el-input type="password" v-model="ruleForm.password" autocomplete="off"></el-input>
			</el-form-item>
			<el-form-item label="New password" prop="newPassword">
				<el-input type="password" v-model="ruleForm.newPassword" autocomplete="off"></el-input>
			</el-form-item>
			<el-form-item label="Repeat password" prop="rePassword">
				<el-input type="password" v-model="ruleForm.rePassword" autocomplete="off"></el-input>
			</el-form-item>
			<el-form-item>
				<el-button type="primary" :disabled="submitFlag" @click="submitForm('ruleForm')">Submit</el-button>
			</el-form-item>
			
		</el-form>
		
	</div>
</template>

<script>
	export default {
		data(){
			var validatePass = (rule, value, callback) => {
				if (value === '') {
					callback(new Error('Please input a new password'));
				} else {
					if (this.ruleForm.rePassword !== '') {
						this.$refs.ruleForm.validateField('rePassword');
					}
					callback();
				}
			}
			var validatePass2 = (rule, value, callback) => {
				if (value === '') {
					callback(new Error('Please enter the password again'));
				} else if (value !== this.ruleForm.newPassword) {
					callback(new Error('The two input passwords are inconsistent!'));
				} else {
					callback();
				}
			}
			
			return {
				//按钮
				submitFlag: false,
				//加载
				loading: false,
				//表单
				ruleForm: {
					userName: '',
					password: '',
					newPassword: '',
					rePassword: '',
				},
				rules: {
					newPassword: [
						{ validator: validatePass, trigger: 'blur' }
					],
					rePassword: [
						{ validator: validatePass2, trigger: 'blur' }
					],
				},
				
			}
		},
		methods: {
			//提交表单
			submitForm(formName) {
				this.$refs[formName].validate((valid) => {
					if (valid) {
						// this.$message({
						// 	message: '123',
						// 	type: 'error'
						// })
						// this.$message({
						// 	message: '123',
						// 	type: 'success'
						// })
						this.submitFlag = true
						this.loading = true
						this.$req.changePassword(this.ruleForm.userName, this.ruleForm.newPassword, this.$store.state.authToken, {
							success: (res)=>{
								console.log(res.data)
								this.submitFlag = false
								this.loading = false
								if(res.data.code == 200){
									this.$message({
										message: 'Password modified successfully!',
										type: 'success'
									})
								}else{
									this.$message({
										message: res.data.msg,
										type: 'error'
									})
								}
							},
							fail: (err)=>{
								console.log(err)
								this.submitFlag = false
								this.loading = false
							}
						})
					} else {
						console.log('error submit!!');
						return false;
					}
				});
			},
		},
		mounted() {
			
		}
	}
</script>

<style lang="less">
	.fs-setting{
		@pubPd: 30px;
		.index-titile{
			text-align: center; 
			color: #409EFF;
		}
		
		.my-ruleForm{
			padding: 30px 30% 30px 30%;
		}
		
	}
</style>
