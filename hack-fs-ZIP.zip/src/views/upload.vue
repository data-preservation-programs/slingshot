<template>
	<div class="fs-upload">
		
		
		<!-- 表单 -->
		<el-form v-loading="isloading" :model="ruleForm" :rules="rules" ref="ruleForm" label-width="auto" label-position="left" class="my-ruleForm">
			<!-- file -->
			<el-form-item label="File">
				<input type="file" @change="getFile($event)"></input>
			</el-form-item>
			
			<!-- classification -->
			<el-form-item label="classification" prop="classification" required>
				<el-select v-model="ruleForm.classification" placeholder="Please select">
					<el-option v-for="(item, index) in classificationList" :key='index' :label="item" :value="item"></el-option>
				</el-select>
			</el-form-item>
			
			<!-- Abstract -->
			<el-form-item label="Abstract" prop="abstract" required>
				<el-input style="width: 600px;" type="textarea" v-model="ruleForm.abstract"></el-input>
			</el-form-item>
			
			<!-- paymentAddress -->
			<el-form-item label="Payment address" prop="paymentAddress" required>
				<el-select v-model="ruleForm.paymentAddress" placeholder="Please select">
					<el-option v-for="(item,index) in $store.state.balancesList" :key="index" :label="item.addr.name" :value="index"></el-option>
				</el-select>
			</el-form-item>
			
			<el-form-item>
				<el-button type="primary" @click="submitForm('ruleForm')">Submit</el-button>
			</el-form-item>
		</el-form>
		
		
	</div>
	
	
	
</template>

<script>
	export default {
		data(){
			return {
				isloading: false,
				customFile: '',
				classificationList: ['Philosophy', 'Economics', 'Law', 'Pedagogy', 'Literature', 'History', 'Science', 'Engineering', 'Agriculture specialty', 'Medicine', 'Military science', 'Management Science', 'Art'],
				ruleForm: {
					paymentAddress: '',
					abstract: '',
					classification: ''
				},
				rules: {
					classification: [
						{ required: true, message: 'Please select classification', trigger: 'blur' }
					],
					abstract: [
						{ required: true, message: 'Please input abstract', trigger: 'blur' }
					],
					paymentAddress: [
						{ required: true, message: 'Please select paymentAddress', trigger: 'change' },
					],
					
				}
			}
		},
		methods: {
			//提交表单
			submitForm(formName) {
				this.$refs[formName].validate((valid) => {
					if (valid) {
						//这里单独验证文件上传
						if(this.customFile){
							let fd = new FormData()
							fd.set('abstract', this.ruleForm.abstract)
							fd.set('description', this.ruleForm.classification)
							fd.set('token', this.$store.state.currentUser.ffsToken)
							fd.set('walletAddr', this.$store.state.balancesList[this.ruleForm.paymentAddress].addr.addr)
							fd.append('file', this.customFile)
							this.isloading = true
							this.$req.apiUpload(fd, this.$store.state.authToken, {
								success: res=>{
									console.log(res)
									this.isloading = false
									if(res.data.code ==200){
										this.$message.success('Upload successful')
										//重置
										this.customFile = ''
										this.$refs[formName].resetFields()
									}else{
										this.$message.error(res.data.msg)
									}
								},
								fail: err=>{
									console.log(err)
									this.isloading = false
								}
							})
						}else{
							this.$message.error('Please select a file')
						}
					} else {
						console.log('error submit!!');
						return false;
					}
				});
			},
			//获取文件
			getFile(e){
				// console.log(e.target.files[0])
				this.customFile = e.target.files[0]
			}
		}
	}
</script>

<style lang="less">
	@pubPd: 30px;
	
	.fs-upload{
		.my-upload{
			padding: @pubPd;
		}
		
		.my-ruleForm{
			box-sizing: border-box;
			padding: 0 @pubPd;
			margin-top: 30px;
		}
	}
	
	// 描述
	.desc-container{
		display: flex;
		flex-direction: row;
		justify-content: start;
		.item{
			margin-right: 10px;
		}
		.item:hover{
			cursor: pointer;
		}
	}
</style>
