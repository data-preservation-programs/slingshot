<template>
	<div class="fs-view-rec">
		<h1 class="index-titile">Browsing history</h1>
		
		<div class="content-list">
			<!-- // 每个文章 -->
			<div v-for="(item, index) in resultList" :key="index" class="content-container">
				<div class="c-title">
					{{item.filename}}
				</div>
				<div class="c-content">
					{{item.time}}
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		data(){
			return {
				resultList: [
					{
						filename: 'Research on risk mechanism of China’s carbon financial.pdf',
						time: '2020-8-5 16:11:57',
					},
					{
						filename: 'Meta-Cognition of Efficacy and Social Media Usage.pdf',
						time: '2020-8-4 20:54:21',
					},
					{
						filename: 'Deep Convolution Neural Network for Big Data.pdf',
						time: '2020-8-3 08:14:23',
					}
				]
			}
		},
		methods: {
			
		},
		mounted() {
			
		}
	}
</script>

<style lang="less">
	.fs-view-rec{
		@pubPd: 30px;
		.index-titile{
			text-align: center; 
			color: #409EFF;
		}
		
		// 文章列表
		.content-list{
			// 每个文章
			.content-container{
				margin-top: 30px;
				margin-bottom: 30px;
				margin-left: 20%;
				margin-right: 20%;
				padding: 20px;
				
				border: 0.5px solid #DCDFE6;
				border-radius: 12px;
				
				.c-title{
					font-size: 20px;
					font-weight: 600;
					margin-bottom: 10px;
				}
				.c-content{
					font-size: 16px;
					color: #777777;
					
					white-space: pre-wrap;/*中文超出换行*/
					word-break:break-all;/*英文超出换行*/
					overflow: hidden;
					text-overflow: ellipsis;
					display: -webkit-box;
					-webkit-box-orient: vertical;
					-webkit-line-clamp:2;
				}
			}
			.content-container:hover{
				cursor: pointer;
				background-color: #8ac9ff;
				*{
					color: #FFFFFF !important;
				}
			}
		}
	}
</style>
