<template>
	<div class="fs-wallet">
		<h1 class="index-titile">Wallet</h1>
		
		<div class="add-wallet">
			<el-button @click="dialogCreateWallet = true" type="primary">CREATE A WALLETADDRESS</el-button>
		</div>
		
		<div class="content-list">
			<!-- // 每个钱包 -->
			<div v-for="(item, index) in $store.state.balancesList" :key="index" class="content-container">
				<div class="main">
					<div class="wallet-img">
						<img src="../static/img/u11.png" />
					</div>
					<div class="wallet-info">
						<div class="c-title">
							{{item.addr.name}}
						</div>
						<div class="c-content">
							{{item.addr.addr}}
						</div>
						<div class="c-content">
							Type:{{item.addr.type}}
						</div>
					</div>
				</div>
				<div class="wallet-balance">
					${{item.balance}}
				</div>
			</div>
		</div>
		
		<!-- 添加钱包表单 -->
		<el-dialog v-loading="loading" title="Create Wallet" :visible.sync="dialogCreateWallet">
			<el-form style="max-width: 80%;" label-position="top" ref="formCreateWallet" :rules="rules" :model="formCreateWallet">
				
				<el-form-item label="WALLET NAME" label-width="auto" prop="name" required>
					<el-input v-model="formCreateWallet.name" autocomplete="off"></el-input>
				</el-form-item>
				
				<el-form-item label="TYPE" label-width="auto" prop="type" required>
					<el-select v-model="formCreateWallet.type" placeholder="SELECT">
						<el-option label="bls" value="bls"></el-option>
					</el-select>
				</el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="dialogCreateWallet = false">Cancel</el-button>
				<el-button type="primary" @click="createWalletSubmit('formCreateWallet')">Submit</el-button>
			</div>
		</el-dialog>
		
	</div>
</template>

<script>
	export default {
		data(){
			return {
				loading: false,
				dialogCreateWallet: false,
				formCreateWallet:{
					name: '',
					type: ''
				},
				rules: {
					name: [
						{ required: true, message: 'NAME required', trigger: 'blur' }
					],
					type: [
						{ required: true, message: 'TYPE required', trigger: 'blur' }
					]
				}
			}
		},
		methods: {
			//新增钱包
			createWalletSubmit(formName){
				this.$refs[formName].validate((valid) => {
					if (valid) {
						this.loading = true
						this.$req.apicreateWallet(this.formCreateWallet.name, this.formCreateWallet.type, this.$store.state.currentUser.ffsToken, this.$store.state.authToken, {
							success: res=>{
								this.loading = false
								if(res.data.code ==200){
									// console.log(res.data.data)
									// console.log(this.$store.state.balancesList)
									this.$store.commit('updateWallet', res.data.data)
									this.$message.success('Success!')
								}else{
									this.$message.error(res.data.msg)
								}
								this.dialogCreateWallet = false
							},
							fail: err=>{
								this.loading = false
								console.log(err)
							}
						})
					} else {
						console.log('error submit!!');
						return false;
					}
				});
				
			}
		},
		mounted() {
			console.log(this.$store.state.balancesList)
		}
	}
</script>

<style lang="less">
	.fs-wallet{
		@pubPd: 30px;
		
		.index-titile{
			text-align: center; 
			color: #409EFF;
		}
		
		.add-wallet{
			width: 100%;
			display: flex;
			flex-direction: row;
			justify-content: space-around;
		}
		
		// 文章列表
		.content-list{
			width: 100%;
			// 每个文章
			.content-container{
				margin: @pubPd;
				padding: 40px;
				margin: 30px 25%;
				
				border: 0.5px solid #DCDFE6;
				border-radius: 12px;
				
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				.main{
					display: flex;
					flex-direction: row;
					align-items: center;
					
					max-width: 55%;
					
					.wallet-img{
						margin-right: 20px;
						img{
							width: 120px;
							height: 120px;
						}
					}
					.c-title{
						color: #42C1CA;
						font-size: 20px;
						font-weight: 600;
						margin-bottom: 10px;
					}
					.c-content{
						font-size: 16px;
						color: #777777;
						
						white-space: pre-wrap;/*中文超出换行*/
						word-break:break-all;/*英文超出换行*/
						// overflow: hidden;
						// text-overflow: ellipsis;
						// display: -webkit-box;
						// -webkit-box-orient: vertical;
						// -webkit-line-clamp:2;
					}
				}
				.wallet-balance{
					max-width: 40%;
					font-size: 18px;
				}
				
			}
			// .content-container:hover{
			// 	cursor: pointer;
			// 	background-color: #8ac9ff;
			// 	*{
			// 		color: #FFFFFF !important;
			// 	}
			// }
		}
		
	}
</style>
