<template>
	<div class="fs-login">
		<h2 style="text-align: center;">Login</h2>
		
		<el-form v-loading="loading" :model="ruleForm" :rules="rules" ref="ruleForm" label-width="auto" class="my-ruleForm">
			<el-form-item label="User" prop="userName">
				<el-input type="text" v-model="ruleForm.userName" autocomplete="off"></el-input>
			</el-form-item>
			<el-form-item label="Password" prop="password">
				<el-input type="password" v-model="ruleForm.password" autocomplete="off"></el-input>
			</el-form-item>
			
			<el-form-item>
				<el-button :disabled="loading" type="primary" @click="submitForm('ruleForm')">Submit</el-button>
			</el-form-item>
			
			<el-form-item>
				<el-link @click="toReg" :underline="false" type="primary">No account? To register</el-link>
			</el-form-item>
		</el-form>
		
	</div>
</template>

<script>
	export default {
		data(){
			return {
				loading: false,
				ruleForm: {
					userName: '',
					password: ''
				},
				rules: {
					userName: [
						{ required: true, message: 'Enter one user name', trigger: 'blur' }
					],
					password: [
						{ required: true, message: 'Please input a password', trigger: 'blur' }
					]
				}
			}
		},
		methods: {
			//提交表单
			submitForm(formName) {
				this.$refs[formName].validate((valid) => {
					if (valid) {
						this.loading = true
						this.$req.apiLogin(this.ruleForm.userName, this.ruleForm.password, {
							success: res=>{
								this.loading = false
								if(res.data.code == 200){
									// console.log(res.data)
									//登录保存状态
									this.$store.commit('login', {
										authToken: res.data.data.AuthToken,
										balancesList: res.data.data.balancesList,
										currentUser: res.data.data.currentuser
									})
									this.$message({
										message: 'Login successful',
										type: 'success'
									})
									//去首页
									this.$router.replace({'path': '/'})
								}else{
									this.$message({
										message: res.data.msg,
										type: 'error'
									})
								}
							},
							fail: err=>{
								this.loading = false
								console.log(err)
							}
						})
					} else {
						console.log('error submit!!');
						return false;
					}
				});
			},
			//去注册
			toReg(){
				this.$router.replace({'path': '/reg'})
			}
		},
		mounted() {
			
		}
	}
</script>

<style lang="less">
	.fs-login{
		.my-ruleForm{
			padding: 30px 30% 30px 30%;
		}
	}
</style>
