<template>
	<div class="fs-download-rec">
		<h1 class="index-titile">Download records</h1>
		
		<div v-loading="isloading" class="content-list">
			<!-- // 每个文章 -->
			<div v-for="(item, index) in resultList" :key="index" class="content-container">
				<div class="c-title">
					{{item.filename}}
				</div>
				<div class="c-content">
					{{item.time}}
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		data(){
			return {
				isloading: false,
				resultList: []
			}
		},
		methods: {
			
		},
		mounted() {
			this.$req.Record(this.$store.state.currentUser.ffsToken, 1, this.$store.state.authToken, {
				success: res=>{
					this.isloading = false
					console.log(res.data.data)
					if(res.data.data){
						this.resultList = res.data.data
						//有记录
						for(let i=0; i<this.resultList.length; i++){
							this.resultList[i].time = this.$common.timestrapToDate(this.resultList[i].time)
						}
					}
				},
				fail: err=>{
					this.isloading = false
					console.log(err)
				}
			})
		}
	}
</script>

<style lang="less">
	.fs-download-rec{
		@pubPd: 30px;
		.index-titile{
			text-align: center; 
			color: #409EFF;
		}
		
		// 文章列表
		.content-list{
			// 每个文章
			.content-container{
				margin-top: 30px;
				margin-bottom: 30px;
				margin-left: 20%;
				margin-right: 20%;
				padding: 20px;
				
				border: 0.5px solid #DCDFE6;
				border-radius: 12px;
				
				.c-title{
					font-size: 20px;
					font-weight: 600;
					margin-bottom: 10px;
				}
				.c-content{
					font-size: 16px;
					color: #777777;
					
					white-space: pre-wrap;/*中文超出换行*/
					word-break:break-all;/*英文超出换行*/
					overflow: hidden;
					text-overflow: ellipsis;
					display: -webkit-box;
					-webkit-box-orient: vertical;
					-webkit-line-clamp:2;
				}
			}
			.content-container:hover{
				// cursor: pointer;
				background-color: #8ac9ff;
				*{
					color: #FFFFFF !important;
				}
			}
		}
	}
</style>
