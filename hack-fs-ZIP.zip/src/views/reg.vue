<template>
	<div class="fs-reg">
		<h2 style="text-align: center;">Register</h2>
		
		<el-form v-loading="loading" :model="ruleForm" :rules="rules" ref="ruleForm" label-width="auto" class="my-ruleForm">
			<el-form-item label="User" prop="userName">
				<el-input type="text" v-model="ruleForm.userName" autocomplete="off"></el-input>
			</el-form-item>
			<el-form-item label="Password" prop="password">
				<el-input type="password" v-model="ruleForm.password" autocomplete="off"></el-input>
			</el-form-item>
			<el-form-item label="Repeat password" prop="rePassword">
				<el-input type="password" v-model="ruleForm.rePassword" autocomplete="off"></el-input>
			</el-form-item>
			<el-form-item label="Mail" prop="email">
				<el-input type="email" v-model="ruleForm.email" autocomplete="off"></el-input>
			</el-form-item>
			<el-form-item>
				<el-button type="primary" :disabled="submitFlag" @click="submitForm('ruleForm')">Submit</el-button>
			</el-form-item>
			
			<el-form-item>
				<el-link @click="toReg" :underline="false" type="primary">Existing account? Go to login</el-link>
			</el-form-item>
		</el-form>
		
	</div>
</template>

<script>
	export default {
		data(){
			var validatePass = (rule, value, callback) => {
				if (value === '') {
					callback(new Error('Please input a password'));
				} else {
					if (this.ruleForm.rePassword !== '') {
						this.$refs.ruleForm.validateField('rePassword');
					}
					callback();
				}
			}
			var validatePass2 = (rule, value, callback) => {
				if (value === '') {
					callback(new Error('Please enter the password again'));
				} else if (value !== this.ruleForm.password) {
					callback(new Error('The two input passwords are inconsistent!'));
				} else {
					callback();
				}
			}
			
			return {
				//按钮
				submitFlag: false,
				//加载
				loading: false,
				//表单
				ruleForm: {
					userName: '',
					password: '',
					rePassword: '',
					email: ''
				},
				rules: {
					userName: [
						{ required: true, message: 'enter one user name', trigger: 'blur' }
					],
					password: [
						{ validator: validatePass, trigger: 'blur' }
					],
					rePassword: [
						{ validator: validatePass2, trigger: 'blur' }
					],
					email: [
						{ required: true, message: 'Please enter email address', trigger: 'blur' }
					]
				}
			}
		},
		methods: {
			//提交表单
			submitForm(formName) {
				this.$refs[formName].validate((valid) => {
					if (valid) {
						// this.$message({
						// 	message: '123',
						// 	type: 'error'
						// })
						// this.$message({
						// 	message: '123',
						// 	type: 'success'
						// })
						this.submitFlag = true
						this.loading = true
						this.$req.apiReg(this.ruleForm.userName, this.ruleForm.password, this.ruleForm.email, {
							success: (res)=>{
								console.log(res.data)
								this.submitFlag = false
								this.loading = false
								if(res.data.code == 200){
									this.$message({
										message: 'Registration successful! Jump to the login page in 3 seconds',
										type: 'success'
									})
									setTimeout(()=>{
										this.$router.replace({'path': '/login'})
									}, 3000)
								}else{
									this.$message({
										message: res.data.msg,
										type: 'error'
									})
								}
							},
							fail: (err)=>{
								console.log(err)
								this.submitFlag = false
								this.loading = false
							}
						})
					} else {
						console.log('error submit!!');
						return false;
					}
				});
			},
			//去登录
			toReg(){
				this.$router.replace({'path': '/login'})
			}
		},
		mounted() {
			
		}
	}
</script>

<style lang="less">
	.fs-reg{
		.my-ruleForm{
			padding: 30px 30% 30px 30%;
		}
	}
</style>
