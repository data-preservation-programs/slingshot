<template>
	<div v-loading="isloading" class="search-result">
		<div class="content-list">
			<!-- // 每个文章 -->
			<div v-for="(item, index) in resultList" :key="index" @click="toArticle(item)" class="content-container">
				<div class="c-title">
					{{item.filename}}
				</div>
				<div class="c-content">
					{{item.abstract}}
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		data(){
			return {
				isloading: false,
				searchContent: '',
				resultList: []
			}
		},
		methods: {
			//去文章详情
			toArticle(item){
				this.$router.push({name: 'article', params: {articleOBJ: item}})
			},
			//检索请求
			doSearch(searchType){
				this.isloading = true
				this.$req.apiRetrieve(this.searchContent, searchType, this.$store.state.authToken, {
					success: res=>{
						this.isloading =false
						if(res.data.code ==200){
							// console.log(res.data)
							this.resultList = res.data.data
						}else{
							this.$message.error(res.data.msg)
							this.$router.replace({'path': '/'})
						}
					},
					fail: err=>{
						this.isloading =false
						console.log(err)
					}
				})
			}
		},
		mounted() {
			// console.log(this.$route.query.searchContent)
			if(this.$route.query.searchType){
				//按类型搜索
				this.searchContent = this.$route.query.searchType
				this.doSearch(2)
			}else {
				//自定义搜索
				this.searchContent = this.$route.query.searchContent
				this.doSearch(1)
			}
		}
	}
</script>

<style lang="less">
	.search-result{
		min-height: 30vh;
		@pubPd: 30px;
		// 文章列表
		.content-list{
			// 每个文章
			.content-container{
				margin: @pubPd;
				padding: 20px;
				
				border: 0.5px solid #DCDFE6;
				border-radius: 12px;
				
				.c-title{
					font-size: 20px;
					font-weight: 600;
					margin-bottom: 10px;
				}
				.c-content{
					font-size: 16px;
					color: #777777;
					
					white-space: pre-wrap;/*中文超出换行*/
					word-break:break-all;/*英文超出换行*/
					overflow: hidden;
					text-overflow: ellipsis;
					display: -webkit-box;
					-webkit-box-orient: vertical;
					-webkit-line-clamp:2;
				}
			}
			.content-container:hover{
				cursor: pointer;
				background-color: #8ac9ff;
				*{
					color: #FFFFFF !important;
				}
			}
		}
	}
</style>
