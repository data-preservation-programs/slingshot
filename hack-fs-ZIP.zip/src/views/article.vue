<template>
	<div class="fs-article">
		<div class="article-container">
			<!-- 标题 -->
			<h1 class="a-title">{{articleOBJ.filename}}</h1>
			<!-- 信息 -->
			<div class="a-info">
				<div>
					<el-tag style="margin-right: 10px;" effect="dark">Author</el-tag>
					<!-- <el-tag style="margin-right: 10px;">张三</el-tag> -->
				</div>
				<div>
					<el-button @click="tapDownload" type="danger">Download</el-button>
				</div>
			</div>
			<!-- 内容 -->
			<div class="a-abstract">Abstract</div>
			<div class="a-content">
				{{articleOBJ.abstract}}
			</div>
		</div>
		
		<!-- 下载支付弹窗 -->
		<el-dialog v-loading="isloading" title="Please feel free to give a reward to the uploader" :visible.sync="dialogPay">
			<el-form style="max-width: 80%;" label-position="top" ref="formPay" :rules="rules" :model="formPay">
				
				<el-form-item label="Amounts" label-width="auto" prop="Amounts" required>
					<el-input style="width: 150px;" type="number" min="1" v-model="formPay.Amounts" autocomplete="off"></el-input>
				</el-form-item>
				
				<el-form-item label="Your Wallet Address" label-width="auto" prop="addr" required>
					<el-select v-model="formPay.addr" placeholder="SELECT">
						<el-option v-for="(item, index) in $store.state.balancesList" :key="index" :label="item.addr.addr" :value="item.addr.addr"></el-option>
					</el-select>
				</el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="dialogPay = false">Cancel</el-button>
				<el-button type="primary" @click="tapPay('formPay')">Submit</el-button>
			</div>
		</el-dialog>
		
		<!-- 下载文件弹窗 -->
		<el-dialog title="Download files" :visible.sync="dialogDownload">
			<el-link :href="fileDownloadURL" target="_blank" type="primary">Download link</el-link>
		</el-dialog>
		
	</div>
</template>

<script>
	export default {
		data(){
			return {
				isloading: false,
				articleOBJ: '',
				dialogPay: false,
				//下载后的文件URL
				fileDownloadURL: '',
				dialogDownload: false,
				formPay: {
					Amounts: '',
					addr: ''
				},
				rules: {
					Amounts: [
						{ required: true, message: 'Please fill in Amounts', trigger: 'blur' }
					],
					addr: [
						{ required: true, message: 'Please select Address', trigger: 'blur' }
					]
				}
			}
		},
		methods: {
			loadArticle(){
				this.articleOBJ = this.$route.params.articleOBJ
				console.log(this.articleOBJ)
			},
			//点击下载
			tapDownload(){
				if(!(this.$store.state.authToken)){
					this.$message.error('Please login and download')
				}else{
					this.dialogPay = true
				}
			},
			//点击支付
			tapPay(formName){
				this.$refs[formName].validate((valid) => {
					if (valid) {
						this.isloading = true
						this.$message.success('Paying...')
						this.$req.apiPayment(this.formPay.addr, this.articleOBJ.walletAddr, this.formPay.Amounts, this.articleOBJ.cid, this.$store.state.currentUser.ffsToken, this.$store.state.authToken, {
							success: res=>{
								if(res.data.code == 200){
									console.log('Payment successful', res.data)
									this.$message.success('Payment successful, requesting file...')
									//文件请求
									this.$req.apiDownload(this.articleOBJ.filename, this.articleOBJ.cid, this.$store.state.currentUser.ffsToken, this.$store.state.authToken, {
										success: res2=>{
											this.isloading = false
											console.log('文件请求success待验证', res2.data)
											if(res2.data){
												if(res2.data.code){
													//有code 则有错误，否则直接data即是文件
													this.$message.error(res2.data.msg)
												}else{
													// res2.data 是后端传过来的文件blob
													// 使用生成链接
													this.fileDownloadURL =  window.URL.createObjectURL(res2.data)
													this.dialogPay = false
													this.dialogDownload = true
												}
											}else{
												this.$message.error('服务器返回无data')
											}
										},
										fail: err2=>{
											this.isloading = false
											console.log(err2)
										}
									})
								}else{
									this.isloading = false
									this.$message.error(res.data.msg)
									console.log(res)
								}
							},
							fail: err=>{
								this.isloading = false
								console.log(err)
							}
						})
					} else {
						console.log('error submit!!');
						return false;
					}
				});
			}
		},
		mounted() {
			this.loadArticle()
		}
	}
</script>

<style lang="less">
	.fs-article{
		@pubPd: 30px;
		.article-container{
			padding: @pubPd;
			.a-title{
				text-align: center;
			}
			.a-info{
				padding: 20px 240px;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
			}
			.a-abstract{
				margin-top: 20px;
				padding: 8px 240px;
				font-weight: 700;
			}
			.a-content{
				padding: 0 240px;
			}
		}
	}
</style>
