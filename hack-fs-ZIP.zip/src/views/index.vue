<template>
  <div class="fs-index">
		<div class="head-logo">
			<img src="../static/img/logo.png" />
		</div>
		<div class="search-input-container">
			<el-input @keyup.enter.native="toResult" placeholder="Please enter the content" v-model="searchContent">
				<el-button @click="toResult" slot="append" icon="el-icon-search"></el-button>
			</el-input>
		</div>
		
		<!-- 分类 -->
		<div class="icon-container">
			<!-- 1行 -->
			<div class="row">
				<div @click="toResultType('Philosophy')" class="r-item">
					<div class="i-icon">
						<img src="../static/img/u97.png" />
					</div>
					<div class="i-txt">Philosophy</div>
				</div>
				
				<div @click="toResultType('Economics')" class="r-item">
					<div class="i-icon">
						<img src="../static/img/u104.png" />
					</div>
					<div class="i-txt">Economics</div>
				</div>
				
				<div @click="toResultType('Science')" class="r-item">
					<div class="i-icon">
						<img src="../static/img/u111.png" />
					</div>
					<div class="i-txt">Science</div>
				</div>
			</div>
			
			<!-- 2行 -->
			<div class="row">
				<div @click="toResultType('Engineering')" class="r-item">
					<div class="i-icon">
						<img src="../static/img/u118.png" />
					</div>
					<div class="i-txt">Engineering</div>
				</div>
				
				<div @click="toResultType('Law')" class="r-item">
					<div class="i-icon">
						<img src="../static/img/u125.png" />
					</div>
					<div class="i-txt">Law</div>
				</div>
				
				<div @click="toResultType('Medicine')" class="r-item">
					<div class="i-icon">
						<img src="../static/img/u132.png" />
					</div>
					<div class="i-txt">Medicine</div>
				</div>
				
				<div @click="toResultType('Management Science')" class="r-item">
					<div class="i-icon">
						<img src="../static/img/u139.png" />
					</div>
					<div class="i-txt">Management Science</div>
				</div>
				
				<div @click="showMore" class="r-item">
					<div class="i-icon">
						<span style="font-size: 50px;" class="el-icon-more"></span>
					</div>
					<div class="i-txt">More</div>
				</div>
			</div>
			
			<!-- 3行 -->
			<div v-show="showFlag" class="row">
				<div @click="toResultType('Pedagogy')" class="r-item">
					<div class="i-icon">
						<img src="../static/img/u175.png" />
					</div>
					<div class="i-txt">Pedagogy</div>
				</div>
				
				<div @click="toResultType('Military Science')" class="r-item">
					<div class="i-icon">
						<img src="../static/img/u154.png" />
					</div>
					<div class="i-txt">Military Science</div>
				</div>
				
				<div @click="toResultType('History')" class="r-item">
					<div class="i-icon">
						<img src="../static/img/u161.png" />
					</div>
					<div class="i-txt">History</div>
				</div>
				
				<div @click="toResultType('Literature')" class="r-item">
					<div class="i-icon">
						<img src="../static/img/u168.png" />
					</div>
					<div class="i-txt">Literature</div>
				</div>
				
				<div @click="toResultType('Art')" class="r-item">
					<div class="i-icon">
						<img src="../static/img/u147.png" />
					</div>
					<div class="i-txt">Art</div>
				</div>
			</div>
		</div>
		
		
  </div>
</template>

<script>
export default {
	data(){
		return {
			//搜索内容
			searchContent: '',
			showFlag: false
		}
	},
	methods: {
		//去搜索结果页 自定义搜索
		toResult(){
			this.$router.push({'path': '/searchResult', query: {searchContent: this.searchContent}})
		},
		//去搜索结果页 按类型搜索
		toResultType(searchType){
			this.$router.push({'path': '/searchResult', query: {searchType: searchType}})
		},
		
		//More显示/隐藏
		showMore(){
			this.showFlag = !this.showFlag
		},
	},
	mounted() {
		
	}
}
</script>

<style lang="less">
	.fs-index{
		@pubPd: 30px;
		
		.index-titile{ 
			text-align: center; 
			color: #409EFF;
		}
		
		.head-logo{
			display: flex;
			flex-direction: row;
			justify-content: center;
		}
		.search-input-container{
			padding: @pubPd 25%;
		}
		
		// 分类图标容器
		.icon-container{
			width: 100%;
			padding: 30px 25%;
			display: flex;
			flex-direction: column;
			align-items: center;
			.row{
				width: 100%;
				display: flex;
				flex-direction: row;
				justify-content: space-around;
				align-items: center;
				margin: 20px 0;
				.r-item{
					width: 20%;
					display: flex;
					flex-direction: column;
					justify-content: center;
					align-items: center;
					.i-icon{
						
					}
					.i-txt{
						
					}
				}
				.r-item:hover{
					cursor: pointer;
				}
			}
		}
		
		
	}
</style>
