<template>
  <div id="app">
		<!-- header -->
		<topHeader></topHeader>
		<!-- body -->
		<div>
			<!-- 内容 -->
			<router-view></router-view>
		</div>
		
		
  </div>
</template>

<script>
	import topHeader from './components/top-header.vue'
	
	export default {
		data(){
			return {
				
			}
		},
		methods: {
			
		},
		components:{
			topHeader
		}
	}
</script>

<style lang="less">
	body{
		padding: 0;
		margin: 0;
	}
	*{
		box-sizing: border-box;
	}
</style>
