import Vue from 'vue'
import VueRouter from 'vue-router'

import index from '../views/index.vue'
import upload from '../views/upload.vue'
import login from '../views/login.vue'
import reg from '../views/reg.vue'
import article from '../views/article.vue'
import searchResult from '../views/search-result.vue'
import wallet from '../views/wallet.vue'
import downloadRec from '../views/download-rec.vue'
import uploadRec from '../views/upload-rec.vue'
import viewRec from '../views/view-rec.vue'
import setting from '../views/setting.vue'

Vue.use(VueRouter)

const routes = [
	{
		path: '/',
		name: 'index',
		component: index
	},
	{
		path: '/upload',
		name: 'upload',
		component: upload
	},
	{
		path: '/login',
		name: 'login',
		component: login
	},
	{
		path: '/reg',
		name: 'reg',
		component: reg
	},
	{
		path: '/article',
		name: 'article',
		component: article
	},
	{
		path: '/searchResult',
		name: 'searchResult',
		component: searchResult
	},
	{
		path: '/wallet',
		name: 'wallet',
		component: wallet
	},
	{
		path: '/downloadRec',
		name: 'downloadRec',
		component: downloadRec
	},
	{
		path: '/uploadRec',
		name: 'uploadRec',
		component: uploadRec
	},
	{
		path: '/viewRec',
		name: 'viewRec',
		component: viewRec
	},
	{
		path: '/setting',
		name: 'setting',
		component: setting
	}
	
]

const router = new VueRouter({
  routes
})

export default router
