import Vue from 'vue'
import App from './App.vue'
import router from './router/router.js'
import store from './store/store.js'

// axios
import axios from 'axios'
import VueAxios from 'vue-axios'
Vue.use(VueAxios, axios)
// ElementUI
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
Vue.use(ElementUI)
//req
import req from './req/req.js'
Vue.prototype.$req = req
//common
import common from './static/js/common.js'
Vue.prototype.$common = common

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
