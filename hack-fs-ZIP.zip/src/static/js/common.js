export default {
	//时间戳转为日期格式
	timestrapToDate(timestamp){
		if(typeof(timestamp)=='string'){
			timestamp = parseInt(timestamp)
		}
		if((timestamp+'').length == 10){
			//10位时间戳 需要*1000
			timestamp = timestamp*1000
		}
		var date = new Date(timestamp)
		var Y = date.getFullYear() + '-';
		var M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
		var D = date.getDate() + ' ';
		
		if(date.getHours()<10){
			var h = '0' + date.getHours() + ':';
		}else{
			var h = date.getHours() + ':';
		}
		
		if(date.getMinutes()<10){
			var m = '0' + date.getMinutes() + ':';
		}else{
			var m = date.getMinutes() + ':';
		}
		
		if(date.getSeconds()<10){
			var s = '0' + date.getSeconds();
		}else{
			var s = date.getSeconds();
		}
		return Y+M+D+h+m+s;
	},
	//日期转时间戳
	dateToTimestrap(date){
		// var date = new Date('2014-04-23 18:55:49:123');
		var date = new Date(date);
		    // 有三种方式获取
		    var time1 = date.getTime();
				return time1
		    // var time2 = date.valueOf();
		    // var time3 = Date.parse(date);
		    // console.log(time1);//1398250549123
		    // console.log(time2);//1398250549123
		    // console.log(time3);//1398250549000
	},
	//去掉所有html标签
	removeHTML(str){
		 //替换掉所有的 html标签，得到html标签中的内容
		var temp = str.replace(/<\/?.+?>/g, "")
		//result为得到后的内容
		var result = temp.replace(/ /g, "")
		return result
	}
}