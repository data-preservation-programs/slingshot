import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
		authToken: '',
		// 钱包地址数组
		balancesList: '',
		//用户信息 username，email，ffsToken
		currentUser: ''
  },
  mutations: {
		//登录
		login(state, data){
			state.authToken = data.authToken
			state.balancesList = data.balancesList
			state.currentUser = data.currentUser
		},
		//登出
		logout(state){
			state.authToken = ''
			state.balancesList = ''
			state.currentUser = ''
		},
		//更新钱包
		updateWallet(state, data){
			state.balancesList = data
		}
  },
  actions: {
  },
  modules: {
  }
})
